package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.CustomerEntity;
import com.entity.ProductEntity;
import com.exception.ProductException;
import com.model.CustomerDTO;
import com.model.ProductDTO;
import com.repository.CustomerRepository;
import com.repository.ProductRepository;

@Service
public class OderService {
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	public ProductDTO getProductDetails(Long id) {
		Optional<ProductEntity> prodEntity = productRepository.findById(id);
		if(prodEntity.isPresent()) {
			return ProductDTO.map(prodEntity.get());
		}else {
			throw new ProductException("Product Not Fond");
		}
	}
	
	public List<ProductDTO> getProductDetails() {
		List<ProductEntity> prodEntities = productRepository.findAll();
		return prodEntities.stream().map(ProductDTO::map).toList();
	}
	
	
	public Boolean createOrder(CustomerDTO customerDTO) {
		CustomerEntity cuEntity = CustomerDTO.map(customerDTO);
		customerRepository.save(cuEntity);
		return Boolean.TRUE;
	}

}
