package com.model;

public class ResponseDTO<T> {
	private T t;
	private String status;
	private String message;
	private String Errors;
	public T getT() {
		return t;
	}
	public void setT(T t) {
		this.t = t;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getErrors() {
		return Errors;
	}
	public void setErrors(String errors) {
		Errors = errors;
	}
	
	

}
