package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.CustomerDTO;
import com.model.ResponseDTO;
import com.service.OderService;

@RestController
public class OrderController {

	@Autowired
	private OderService oderService;

	@PostMapping("/create")
	public ResponseDTO createOder(@RequestBody CustomerDTO customerDTO) {
		oderService.createOrder(customerDTO);
		ResponseDTO<CustomerDTO> response = new ResponseDTO<>();
		response.setStatus("Order create Successfully");
		return response;
	}
}
