package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.ProductDTO;
import com.model.ResponseDTO;
import com.service.ProductService;

import jakarta.websocket.server.PathParam;

@RestController
public class ProductController {

	@Autowired
	private ProductService productService;

	@GetMapping("/products/{id}")
	public ResponseDTO getProduct(@PathParam("id") Long id) {
		ProductDTO dto = productService.getProductDetails(id);
		ResponseDTO<ProductDTO> response = new ResponseDTO<>();
		response.setT(dto);
		return response;
	}

	@GetMapping("/products")
	public ResponseDTO getProduct() {
		List<ProductDTO> dto = productService.getProductDetails();
		ResponseDTO<List<ProductDTO>> response = new ResponseDTO<>();
		response.setT(dto);
		return response;
	}
}
