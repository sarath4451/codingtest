package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.CustomerDTO;
import com.model.ProductDTO;
import com.model.ResponseDTO;
import com.service.ProductService;

import jakarta.websocket.server.PathParam;

@RestController
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@GetMapping("/products/{id}")
	public ResponseDTO getProduct(@PathParam("id") Long id) {
		ProductDTO dto= productService.getProductDetails(id);
		ResponseDTO<ProductDTO> response = new ResponseDTO<>();
		response.setT(dto);	
		return response;
	}

	@PostMapping("")
	public ResponseDTO createOder(@RequestBody CustomerDTO customerDTO) {
		productService.createOrder(customerDTO);
		ResponseDTO<CustomerDTO> response = new ResponseDTO<>();
		response.setStatus("Order create Successfully");
		return response;
	}
}
