package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.CustomerEntity;
import com.model.CustomerDTO;
import com.repository.CustomerRepository;

@Service
public class OderService {

	@Autowired
	private CustomerRepository customerRepository;

	public Boolean createOrder(CustomerDTO customerDTO) {
		CustomerEntity cuEntity = CustomerDTO.map(customerDTO);
		customerRepository.save(cuEntity);
		return Boolean.TRUE;
	}

}
