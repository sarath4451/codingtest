package com.model;

import java.util.List;

import org.springframework.beans.BeanUtils;

import com.entity.CustomerEntity;


public class CustomerDTO {

	private Long id;

	private String custName;
	
	private List<ProductDTO> products;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public List<ProductDTO> getProducts() {
		return products;
	}

	public void setProducts(List<ProductDTO> products) {
		this.products = products;
	}
	
	
	public static CustomerEntity map(CustomerDTO customerDTO) {
		CustomerEntity entity = new CustomerEntity();
		BeanUtils.copyProperties(customerDTO, entity);
		return entity;
	}
	
}
